package mongo;
//importing input/output packages for java
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.*;
//Importing Com.mongodb packages..
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.model.Updates;

public class mongoproj {

	private static final DBCursor BasicDBObject = null;
	public static String read;
	public String[] s; //Declaring a String read.
	public String[] p;
	ArrayList<String> al=new ArrayList<String>();
	ArrayList<String>lname=new ArrayList<String>();
	ArrayList<String>Fname=new ArrayList<String>();
	
	public static void main(String[] args) {
		//main class
		new mongoproj().Fileread_fromtext();

	}

	public void Fileread_fromtext() {
		//initializing the string with file location
		String filelocation = "E:/root/project.txt";
		FileInputStream is;
		BufferedReader br;

		String read_file;
		try {
			//try catch block for reading file from the location
			is = new FileInputStream(filelocation);
			//object for buffered reader.
			br = new BufferedReader(new InputStreamReader(is));

			String l = br.readLine();
			///while loop for traversing through the loop
			while (l != null) {
				read_file = l;
				l = br.readLine();
				read = read_file;
				s = read.split(",");  //spliting the string using ","
				
				
				   //try catch block for mongodb collection. 
				try {
					
					MongoClient mongo = new MongoClient("localhost", 27017);
					DB db = mongo.getDB("ame");//getting the db .
					///getting or creating the collection in mongodb
					
					DBCollection col = db.getCollection("Projecdt2");
					
					//System.out.println(doc);
					DBCursor cur = col.find();
					
					DBObject query = new BasicDBObject("Pnumber.number", new BasicDBObject("$exists", true));
					DBCursor result = col.find(query);
					System.out.println(result.size());
					
					if(result.size()==0)
					{  
					al.add(s[0]); //inserting data in to array list
					BasicDBObject document = new BasicDBObject("Pnumber", new BasicDBObject("number", s[0]));
					BasicDBObject d = new BasicDBObject(s[4], new BasicDBObject("Hours", s[5]) );
					BasicDBObject doc = new BasicDBObject("Firstname", d);
					BasicDBObject dd = new BasicDBObject(s[3], doc );
					document.put("Pname", s[1]);
					document.put("Department", s[2]);
					document.put("Employee", new BasicDBObject("Lastname", dd) );
					
					col.insert(document);
					
					while (cur.hasNext()) {

						System.out.println(cur.next());
					}

					mongo.close();
					}
					
					
					else if(result.size()!=0 && al.contains(s[0]) ){
						
						System.out.println("....");
						al.add(s[0]);
						
						BasicDBObject gtQuery = new BasicDBObject();
						gtQuery.put("Pname", s[1]);
						
						BasicDBObject fifi = new BasicDBObject(s[4], new BasicDBObject("Hours", s[5]) );
					
						BasicDBObject fi = new BasicDBObject("Firstname", fifi );
						BasicDBObject dd = new BasicDBObject(s[3], fi );
						
						BasicDBObject lnn = new BasicDBObject("Lastname", dd );
						
						DBObject listItem = new BasicDBObject(" Employee.Lastname", lnn);
						DBObject updateQuery = new BasicDBObject("$push", listItem); ///pushing data in same object.
						col.update(gtQuery, updateQuery); ///updating the collection
						DBCursor res = col.find(gtQuery);
						
						while (res.hasNext()) {
							
							System.out.println(res.next());
							
						}
						
						mongo.close(); //closing db
					}
					
					else if(result.size()!=0 && al.contains(s[0])==false){
						System.out.println(".$$$$$.");
						al.add(s[0]);  //adding Pnumber in arraylist
						BasicDBObject document = new BasicDBObject("Pnumber", new BasicDBObject("number", s[0]));
						BasicDBObject d = new BasicDBObject(s[4], new BasicDBObject("Hours", s[5]) );
						BasicDBObject doc = new BasicDBObject("Firstname", d);
						BasicDBObject dd = new BasicDBObject(s[3], doc );
						document.put("Pname", s[1]);
						document.put("Department", s[2]);
						document.put("Employee", new BasicDBObject("Lastname", dd) );
						
						col.insert(document); //inserting document in nt db
						
						while (cur.hasNext()) {

							System.out.println(cur.next()); //printing results
						}

						mongo.close();
						
						//closing mongodb connection
					}
				

				} catch (Exception e) {
					e.printStackTrace();			}

			}
            
		
			br.close();

		} catch (Exception e) {
			System.out.println(
					"Something went wrong!! Please check the file location should be saved in E:/root)");
		}

	}

}
