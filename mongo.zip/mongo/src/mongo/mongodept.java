package mongo;

//importing input/output packages for java 
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.*;
//Importing Com.mongodb packages..
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.model.Updates;

public class mongodept {
    
	private static final DBCursor BasicDBObject = null;
	public static String read; //Declaring a String read.
	public String[] s; //Declaring a String  array .
	public String[] p;
	//Declaring a String  array list.
	ArrayList<String> al=new ArrayList<String>();
	
	
	public static void main(String[] args) {
//main class
		new mongodept().Fileread_fromtext();

	}

	public void Fileread_fromtext() {
		//initializing the string with file location
		String filelocation = "E:/root/dept.txt";
		FileInputStream is;
		BufferedReader br;

		String read_file;
		try {
			//try catch block for reading file from the location 
			is = new FileInputStream(filelocation);
//object for buffered reader.
			br = new BufferedReader(new InputStreamReader(is));

			String l = br.readLine();
///while loop for traversing through the loop
			while (l != null) {
				read_file = l;
				l = br.readLine();
				read = read_file;
				s = read.split(","); //spliting the string using ","
				
				
             //try catch block for mongodb collection.
				try {
					
					MongoClient mongo = new MongoClient("localhost", 27017);
					DB db = mongo.getDB("ame"); //getting the db .
					///getting or creating the collection in mongodb
					DBCollection col = db.getCollection("Dest");
					
					//System.out.println(doc);
					DBCursor cur = col.find();
					//creating a object
					DBObject query = new BasicDBObject("DepartmentName", new BasicDBObject("$exists", true));
					//creating a object
					DBCursor result = col.find(query);
					System.out.println(result.size());
					///first if loop to check through the size of collection.
					if(result.size()==0)
					{  
					al.add(s[0]); //inserting data in to array.
					
					BasicDBObject document = new BasicDBObject("DepartmentName", s[0]);
					document.put("Manage_lastname", s[1]);
					///putting values in the object
					document.put("Department", new BasicDBObject("location", s[2]) );
					
					col.insert(document);
					//inserting object in-to mongodb collection
					while (cur.hasNext()) {

						System.out.println(cur.next()); //printing op
					}

					mongo.close(); //closing mongo colleaction.
					}
					
					//if loop 
					else if(result.size()!=0 && al.contains(s[0]) ){
						
						System.out.println("....");
						al.add(s[0]); //adding element in the array list.
						
						BasicDBObject gtQuery = new BasicDBObject();
						gtQuery.put("DepartmentName", s[0]);
						
						
						
						DBObject listItem = new BasicDBObject(" Department.location", s[2]);
						DBObject updateQuery = new BasicDBObject("$push", listItem); ///pushing data in same object.
						col.update(gtQuery, updateQuery);///updating the collection
						DBCursor res = col.find(gtQuery);
						
						while (res.hasNext()) {
							
							System.out.println(res.next()); //printing result
							
						}
						
						
					}
					///if loop 
					else if(result.size()!=0 && al.contains(s[0])==false){
						System.out.println(".$$$$$.");
						al.add(s[0]);//adding DepartmentName in arraylist
						BasicDBObject document = new BasicDBObject("DepartmentName", s[0]);
						document.put("Manager_Lastname", s[1]);
						document.put("Department", new BasicDBObject("location", s[2]) );
						
						col.insert(document);
						
						while (cur.hasNext()) {

							System.out.println(cur.next()); //printing objects.
						}

						mongo.close();
					//closing mongodb connection
						
					}
					

				} catch (Exception e) {
					e.printStackTrace();	}

			}
            
		
			br.close();

		} catch (Exception e) {
			System.out.println(
					"Something went wrong!!");
		}

	}

}

